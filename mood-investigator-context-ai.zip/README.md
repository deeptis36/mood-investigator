# 🕵️ Mood Investigator — Context AI

A context-aware mood investigation web app.

Unlike a keyword matcher, the backend first tries to understand **what is happening in the sentence**, then uses that context to infer likely emotional signals.

Examples:

- `I have lost my mobile.` → likely worry/distress
- `Today is my birthday.` → likely joy/celebration
- `I got the promotion, but I still feel empty.` → can detect positive context plus a heavier emotional signal
- `My interview is tomorrow and I haven't prepared.` → likely anxiety/uncertainty

## Technology

- FastAPI
- Hugging Face Transformers
- `MoritzLaurer/deberta-v3-base-zeroshot-v1.1-all-33`
- PyTorch
- HTML + CSS + JavaScript

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

Open:

```text
http://127.0.0.1:8000/
```

The first run downloads the model and can take a while. The model is then cached locally.

## Architecture

```text
Sentence
   ↓
Context / situation inference
   ↓
Situation + original sentence
   ↓
Emotion inference
   ↓
Primary emotion + secondary signals
   ↓
Beautiful investigation result
```

## Important

This is an AI interpretation of language. It cannot know a person's actual internal state with certainty and is not a medical or psychological diagnosis.

## Model

The zero-shot model is from Hugging Face:

`MoritzLaurer/deberta-v3-base-zeroshot-v1.1-all-33`

Model page:
https://huggingface.co/MoritzLaurer/deberta-v3-base-zeroshot-v1.1-all-33
